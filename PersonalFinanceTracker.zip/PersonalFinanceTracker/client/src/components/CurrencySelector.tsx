import { useState } from 'react';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { CURRENCY_SYMBOLS, CURRENCY_NAMES } from '@/lib/currency';
import { SUPPORTED_CURRENCIES, Currency } from '@shared/schema';

interface CurrencySelectorProps {
  value: Currency;
  onChange: (currency: Currency) => void;
  className?: string;
}

export function CurrencySelector({ value, onChange, className }: CurrencySelectorProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={className}>
        <SelectValue>
          {CURRENCY_SYMBOLS[value]} {CURRENCY_NAMES[value]}
        </SelectValue>
      </SelectTrigger>
      <SelectContent>
        {SUPPORTED_CURRENCIES.map((currency) => (
          <SelectItem key={currency} value={currency}>
            {CURRENCY_SYMBOLS[currency]} {CURRENCY_NAMES[currency]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}