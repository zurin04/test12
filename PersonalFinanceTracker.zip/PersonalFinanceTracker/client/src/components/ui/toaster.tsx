export function Toaster() {
  return <div id="toaster" />;
}