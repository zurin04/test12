import { Currency } from '@shared/schema';

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: '$',
  PHP: '₱',
};

export const CURRENCY_NAMES: Record<Currency, string> = {
  USD: 'US Dollar',
  PHP: 'Philippine Peso',
};

export const formatCurrency = (amount: number, currency: Currency): string => {
  const symbol = CURRENCY_SYMBOLS[currency];
  return `${symbol}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

export const parseCurrencyAmount = (value: string): number => {
  // Remove currency symbols and commas, then parse
  const cleaned = value.replace(/[^\d.-]/g, '');
  return parseFloat(cleaned) || 0;
};

// Default exchange rates (in real app, these would come from API)
export const DEFAULT_EXCHANGE_RATES: Record<Currency, number> = {
  USD: 1,
  PHP: 56.5,
};

export const convertCurrency = (
  amount: number,
  fromCurrency: Currency,
  toCurrency: Currency,
  exchangeRates: Record<Currency, number> = DEFAULT_EXCHANGE_RATES
): number => {
  if (fromCurrency === toCurrency) return amount;
  
  // Convert to USD first, then to target currency
  const usdAmount = fromCurrency === 'USD' ? amount : amount / exchangeRates[fromCurrency];
  return toCurrency === 'USD' ? usdAmount : usdAmount * exchangeRates[toCurrency];
};