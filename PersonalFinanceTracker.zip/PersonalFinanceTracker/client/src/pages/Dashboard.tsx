import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { Plus, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CurrencySelector } from '@/components/CurrencySelector';
import { formatCurrency } from '@/lib/currency';
import { Currency, Task, Income, Expense, Bill, PnLData } from '@shared/schema';

export function Dashboard() {
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('USD');
  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  // Fetch data
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const { data: incomes = [] } = useQuery<Income[]>({
    queryKey: ['/api/incomes'],
  });

  const { data: expenses = [] } = useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
  });

  const { data: bills = [] } = useQuery<Bill[]>({
    queryKey: ['/api/bills'],
  });

  const { data: pnlData } = useQuery<PnLData>({
    queryKey: ['/api/pnl', selectedDate, selectedCurrency],
    queryFn: () =>
      fetch(`/api/pnl?date=${selectedDate}&currency=${selectedCurrency}`)
        .then(res => res.json()),
  });

  // Prepare calendar events
  const events = [
    ...tasks.map(task => ({
      id: `task-${task.id}`,
      title: task.title,
      date: task.dueDate,
      className: 'fc-event-task',
      extendedProps: {
        type: 'task',
        data: task,
      },
    })),
    ...incomes.map(income => ({
      id: `income-${income.id}`,
      title: `+${formatCurrency(income.amount, income.currency)} ${income.description}`,
      date: income.date,
      className: 'fc-event-income',
      extendedProps: {
        type: 'income',
        data: income,
      },
    })),
    ...expenses.map(expense => ({
      id: `expense-${expense.id}`,
      title: `-${formatCurrency(expense.amount, expense.currency)} ${expense.description}`,
      date: expense.date,
      className: 'fc-event-expense',
      extendedProps: {
        type: 'expense',
        data: expense,
      },
    })),
    ...bills.map(bill => ({
      id: `bill-${bill.id}`,
      title: `Bill: ${formatCurrency(bill.amount, bill.currency)} ${bill.description}`,
      date: bill.dueDate,
      className: 'fc-event-bill',
      extendedProps: {
        type: 'bill',
        data: bill,
      },
    })),
  ];

  // Calculate totals for today
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayEnd = new Date();
  todayEnd.setHours(23, 59, 59, 999);

  const todayIncomes = incomes.filter(income => {
    const incomeDate = new Date(income.date);
    return incomeDate >= todayStart && incomeDate <= todayEnd;
  });

  const todayExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate >= todayStart && expenseDate <= todayEnd;
  });

  const totalIncome = todayIncomes.reduce((sum, income) => sum + income.amount, 0);
  const totalExpenses = todayExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const todayPnL = totalIncome - totalExpenses;

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl font-bold">Personal Finance Tracker</h1>
            <div className="flex items-center gap-4">
              <CurrencySelector
                value={selectedCurrency}
                onChange={setSelectedCurrency}
                className="w-48"
              />
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Entry
              </Button>
            </div>
          </div>

          {/* Daily Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-card p-4 rounded-lg border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's Income</p>
                  <p className="text-2xl font-bold text-green-600">
                    {formatCurrency(totalIncome, selectedCurrency)}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </div>

            <div className="bg-card p-4 rounded-lg border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's Expenses</p>
                  <p className="text-2xl font-bold text-red-600">
                    {formatCurrency(totalExpenses, selectedCurrency)}
                  </p>
                </div>
                <TrendingDown className="w-8 h-8 text-red-600" />
              </div>
            </div>

            <div className="bg-card p-4 rounded-lg border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today's P&L</p>
                  <p className={`text-2xl font-bold ${
                    todayPnL >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {formatCurrency(todayPnL, selectedCurrency)}
                  </p>
                </div>
                <DollarSign className="w-8 h-8 text-blue-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Calendar */}
        <div className="bg-card p-6 rounded-lg border">
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            headerToolbar={{
              left: 'prev,next today',
              center: 'title',
              right: 'dayGridMonth,timeGridWeek,timeGridDay',
            }}
            events={events}
            eventClick={(info) => {
              console.log('Event clicked:', info.event.extendedProps);
            }}
            dateClick={(info) => {
              setSelectedDate(info.dateStr);
            }}
            height="auto"
            dayMaxEventRows={3}
            moreLinkClick="popover"
          />
        </div>
      </div>
    </div>
  );
}