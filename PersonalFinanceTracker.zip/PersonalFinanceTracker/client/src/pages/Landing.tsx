import { Button } from "@/components/ui/button";

export function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
      <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow-lg">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Personal Finance Tracker
          </h1>
          <p className="text-gray-600 mb-8">
            Track your finances and tasks with multi-currency support for USD and PHP
          </p>
        </div>
        
        <div className="space-y-4">
          <div className="text-center text-sm text-gray-500">
            Sign in to access your financial dashboard
          </div>
          
          <Button 
            onClick={() => window.location.href = '/api/login'}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            Sign In with Replit
          </Button>
        </div>

        <div className="mt-8 text-center text-xs text-gray-400">
          Features: Multi-currency support, Task management, Calendar view, PnL tracking
        </div>
      </div>
    </div>
  );
}