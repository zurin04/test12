# VPS Deployment Guide - Personal Finance Tracker

## One-Click Deployment

This script provides automated deployment of your Personal Finance Tracker to any Ubuntu VPS.

### Prerequisites

- Ubuntu 18.04+ VPS with sudo access
- At least 2GB RAM (4GB recommended)
- Domain name (optional, for SSL)

### Quick Start

1. **Upload your code to the VPS:**
   ```bash
   # Clone or upload your project files to the VPS
   git clone <your-repo-url>
   cd your-project-directory
   ```

2. **Run the deployment script:**
   ```bash
   chmod +x deploy-vps.sh
   ./deploy-vps.sh
   ```

3. **Access your application:**
   - The script will display your server IP at the end
   - Visit `http://your-server-ip` to access your finance tracker

### What the Script Does

✅ **System Setup:**
- Installs Node.js 20, PostgreSQL, Nginx, PM2
- Configures firewall and security settings

✅ **Database Setup:**
- Creates PostgreSQL database and user
- Generates secure credentials
- Pushes database schema

✅ **Application Configuration:**
- Builds the React frontend
- Configures the Express backend
- Sets up PM2 for process management
- Configures Nginx as reverse proxy

✅ **Production Optimization:**
- Gzip compression
- Security headers
- Automatic restarts
- Log management

### Post-Deployment Management

The script creates a `manage.sh` file with useful commands:

```bash
# Check application status
./manage.sh status

# Create database backup
./manage.sh backup

# Safe update with automatic backup
./manage.sh update

# Setup SSL certificate (requires domain)
./manage.sh ssl yourdomain.com

# Restart application
./manage.sh restart
```

### SSL Certificate Setup

After pointing your domain to the server:

```bash
./manage.sh ssl yourdomain.com
```

This will:
- Configure Nginx for your domain
- Install Let's Encrypt SSL certificate
- Enable HTTPS redirects

### Monitoring

```bash
# View application logs
pm2 logs finance-tracker

# Real-time monitoring
pm2 monit

# Check system status
./verify-deployment.sh
```

### Troubleshooting

**Application not starting:**
```bash
pm2 logs finance-tracker
```

**Database connection issues:**
```bash
sudo systemctl status postgresql
```

**Nginx configuration problems:**
```bash
sudo nginx -t
sudo systemctl status nginx
```

### Architecture

**Frontend (Port 80/443):**
- Nginx serves static React build files
- Proxies API requests to backend

**Backend (Port 5000):**
- Express server with authentication
- Database connections
- API endpoints

**Database (Port 5432):**
- PostgreSQL with secure credentials
- Automatic schema management

### Security Features

- Firewall configured (ports 22, 80, 443)
- Secure database credentials
- Session management
- Security headers
- HTTPS support

### File Structure After Deployment

```
/var/www/finance-tracker/
├── client/dist/          # Built React frontend
├── server/              # Express backend
├── shared/              # Shared schemas
├── .env                 # Environment variables
├── ecosystem.config.js  # PM2 configuration
├── manage.sh           # Management scripts
└── verify-deployment.sh # Verification script
```

### Environment Variables

The deployment automatically configures:

- `DATABASE_URL` - PostgreSQL connection
- `SESSION_SECRET` - Session encryption
- `NODE_ENV=production`
- `PORT=5000`
- Database credentials

### Backup Strategy

Automatic backups available:

```bash
# Manual backup
./manage.sh backup

# Restore from backup
./manage.sh restore /path/to/backup.sql

# Backups are stored in /var/backups/finance-tracker/
```

### Updates

Safe updates with automatic rollback:

```bash
./manage.sh update
```

This process:
1. Creates backup
2. Pulls latest code
3. Updates dependencies
4. Migrates database
5. Rebuilds application
6. Restarts services
7. Rolls back if any step fails

### Support

For issues or questions:
1. Check logs: `pm2 logs finance-tracker`
2. Run verification: `./verify-deployment.sh`
3. Check service status: `./manage.sh status`

The deployment script provides a complete production environment with monitoring, backups, and easy management for your Personal Finance Tracker application.