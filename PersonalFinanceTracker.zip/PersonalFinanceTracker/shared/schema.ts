import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  decimal,
  integer,
} from "drizzle-orm/pg-core";

// Currency types
export const SUPPORTED_CURRENCIES = ['USD', 'PHP'] as const;
export type Currency = typeof SUPPORTED_CURRENCIES[number];

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  status: varchar("status", { enum: ['to-do', 'in-progress', 'completed'] }).default('to-do'),
  dueDate: timestamp("due_date").notNull(),
  priority: varchar("priority", { enum: ['low', 'medium', 'high'] }).default('medium'),
  category: varchar("category").notNull(),
  linkedGoalId: varchar("linked_goal_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const incomes = pgTable("incomes", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { enum: SUPPORTED_CURRENCIES }).notNull(),
  category: varchar("category", { enum: ['goal', 'credit'] }).notNull(),
  description: varchar("description").notNull(),
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { enum: SUPPORTED_CURRENCIES }).notNull(),
  category: varchar("category").notNull(),
  description: varchar("description").notNull(),
  date: timestamp("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bills = pgTable("bills", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { enum: SUPPORTED_CURRENCIES }).notNull(),
  description: varchar("description").notNull(),
  dueDate: timestamp("due_date").notNull(),
  status: varchar("status", { enum: ['paid', 'unpaid'] }).default('unpaid'),
  createdAt: timestamp("created_at").defaultNow(),
});

export const goals = pgTable("goals", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  targetAmount: decimal("target_amount", { precision: 10, scale: 2 }).notNull(),
  currency: varchar("currency", { enum: SUPPORTED_CURRENCIES }).notNull(),
  taskIds: jsonb("task_ids").$type<string[]>().default([]),
  taskProgress: integer("task_progress").default(0),
  deadline: timestamp("deadline").notNull(),
  category: varchar("category").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const currencySettings = pgTable("currency_settings", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull().unique(),
  primaryCurrency: varchar("primary_currency", { enum: SUPPORTED_CURRENCIES }).notNull(),
  exchangeRate: decimal("exchange_rate", { precision: 10, scale: 4 }),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Types
export type User = typeof users.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Income = typeof incomes.$inferSelect;
export type Expense = typeof expenses.$inferSelect;
export type Bill = typeof bills.$inferSelect;
export type Goal = typeof goals.$inferSelect;
export type CurrencySettings = typeof currencySettings.$inferSelect;

export type UpsertUser = typeof users.$inferInsert;
export type InsertTask = typeof tasks.$inferInsert;
export type InsertIncome = typeof incomes.$inferInsert;
export type InsertExpense = typeof expenses.$inferInsert;
export type InsertBill = typeof bills.$inferInsert;
export type InsertGoal = typeof goals.$inferInsert;
export type InsertCurrencySettings = typeof currencySettings.$inferInsert;

// PnL Data type
export type PnLData = {
  date: string;
  income: number;
  expenses: number;
  pnl: number;
  currency: Currency;
};

// External API URL for exchange rates
export const EXCHANGE_RATE_API_URL = 'https://api.exchangerate-api.com/v4/latest/USD';