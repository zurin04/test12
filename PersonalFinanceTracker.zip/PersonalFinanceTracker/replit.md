# Personal Finance Tracker

## Overview

This is a full-stack web application for tracking personal finances and tasks with multi-currency support (USD/PHP). The application provides a comprehensive solution for managing daily income, expenses, bills, dues, and tasks with a calendar view interface. Built with React.js frontend and Node.js/Express backend, using in-memory storage for rapid development and prototyping.

## System Architecture

### Frontend Architecture
- **Framework**: React.js with functional components and hooks
- **Calendar Integration**: FullCalendar for calendar view functionality
- **Styling**: Tailwind CSS for responsive and modern UI design
- **State Management**: React hooks (useState, useEffect) for local state management
- **API Communication**: Fetch API or Axios for backend communication

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Authentication**: Replit Auth with OpenID Connect OAuth flow
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Management**: Database-backed session storage with connect-pg-simple
- **Currency Support**: Built-in USD/PHP conversion with configurable exchange rates
- **API Design**: RESTful API endpoints with authentication middleware
- **Security**: Protected routes requiring valid JWT tokens and session validation

### Data Storage
- **Primary Storage**: PostgreSQL database with Drizzle ORM
- **Schema Definition**: Drizzle schema with proper TypeScript type inference
- **Session Storage**: Database-backed sessions for authentication persistence
- **User Management**: Complete user profile management with Replit Auth integration
- **Currency Support**: Database-stored currency settings with real-time conversion

## Key Components

### Data Models
1. **Task Schema**
   - User identification (userId)
   - Task metadata (title, description, status, dueDate, priority, category)
   - Goal linking capability (linkedGoalId)
   - Status tracking (to-do, in-progress, completed)
   - Priority levels (low, medium, high)

2. **Income Schema**
   - User identification (userId)
   - Financial data (amount, category, description, date)
   - Category types (goal, credit)

3. **Additional Models** (implied but not shown in current code)
   - Expense tracking
   - Bill management
   - Due date tracking

### Frontend Components
- Calendar view for visualizing tasks and financial events
- Task management interface
- Income/expense tracking forms
- Dashboard for financial overview

## Data Flow

1. **User Interaction**: User interacts with React components
2. **API Requests**: Frontend sends HTTP requests to Express backend
3. **Database Operations**: Backend processes requests and interacts with MongoDB
4. **Response Handling**: Data flows back through the same path
5. **State Updates**: Frontend updates UI based on received data

## External Dependencies

### Backend Dependencies
- `express`: Web application framework
- `mongoose`: MongoDB object modeling
- `dotenv`: Environment variable management
- `cors`: Cross-origin resource sharing middleware

### Frontend Dependencies
- `react`: Core React library
- `fullcalendar`: Calendar component library
- `tailwindcss`: Utility-first CSS framework

### External Services
- **MongoDB Atlas**: Cloud database service
- **Replit**: Development and hosting environment

## Deployment Strategy

### Development Environment
- **Development Environment**: Replit's built-in Node.js environment
- **Package Management**: npm for dependency management
- **Environment Variables**: .env file for sensitive configuration
- **Port Configuration**: Client on port 3000, Server on port 3001
- **Database**: PostgreSQL with Drizzle ORM for production-ready database

### Production VPS Deployment
- **One-Click Deployment**: Automated VPS deployment script (`deploy-vps.sh`)
- **Supported Platforms**: Ubuntu 18.04+ VPS servers
- **Process Management**: PM2 for application lifecycle management
- **Web Server**: Nginx as reverse proxy with SSL support
- **Database**: PostgreSQL with automated schema management
- **Security**: Firewall configuration, secure credentials, HTTPS support
- **Monitoring**: Built-in logging and monitoring tools
- **Backup System**: Automated database backups and safe update procedures

## User Preferences

Preferred communication style: Simple, everyday language.

## Currency Support Features

### Multi-Currency Implementation
- **Supported Currencies**: USD (US Dollar) and PHP (Philippine Peso)
- **Currency Selection**: Dropdown selector for switching between currencies
- **Real-time Conversion**: Automatic conversion between currencies using configurable exchange rates
- **Default Exchange Rate**: 1 USD = 56.5 PHP (configurable in backend)

### Currency Components
- **CurrencySelector**: React component for currency selection with proper symbols
- **Currency Utilities**: Helper functions for formatting and conversion
- **Backend Storage**: All financial records store currency information
- **PnL Calculation**: Profit & Loss calculations support multi-currency with conversion

### Technical Implementation
- **Schema Design**: All financial models include currency field (USD/PHP enum)
- **Type Safety**: Zod validation ensures currency consistency
- **API Endpoints**: Support currency parameter for PnL calculations
- **Frontend State**: Currency selection persists across user session
- **Formatting**: Proper currency symbols ($ for USD, ₱ for PHP) with locale formatting

## Changelog

Changelog:
- July 05, 2025. Initial setup with USD/PHP currency support
- July 05, 2025. Implemented multi-currency personal finance tracker with:
  - Full-stack application with React frontend and Express backend
  - USD/PHP currency support with conversion capabilities
  - Calendar view using FullCalendar for visualizing financial data
  - In-memory storage for rapid development and prototyping
  - Comprehensive API with Zod validation for type safety
- July 05, 2025. **Major Update**: Implemented authentication and database integration:
  - **Replit Auth Integration**: Added complete OAuth-based signup/signin using OpenID Connect
  - **PostgreSQL Database**: Migrated from in-memory to persistent PostgreSQL storage using Drizzle ORM
  - **Session Management**: Implemented secure session storage with database persistence
  - **User Management**: Added user profiles with email, names, and profile images
  - **Protected Routes**: All API endpoints now require authentication for data access
  - **Database Schema**: Complete schema with users, tasks, incomes, expenses, bills, goals, and currency settings tables
  - **Authentication Flows**: Login/logout redirects and session refresh token management
  - **Frontend Authentication**: Complete authentication flow with Landing page, Home page, and protected routes
  - **Authentication Status**: ✅ COMPLETED - Full authentication system is now operational
- July 05, 2025. **Production Deployment**: Added one-click VPS deployment capability:
  - **VPS Deployment Script**: Created comprehensive `deploy-vps.sh` for Ubuntu VPS deployment
  - **Production Architecture**: Nginx reverse proxy, PM2 process management, PostgreSQL database
  - **Security Features**: Firewall configuration, SSL certificate support, secure credential generation
  - **Management Tools**: Created `manage.sh` for backup, update, SSL setup, and monitoring
  - **Deployment Documentation**: Complete VPS deployment guide with troubleshooting
  - **Automated Setup**: One-command deployment with verification and status checking
  - **Production Ready**: ✅ COMPLETED - Application ready for production VPS deployment