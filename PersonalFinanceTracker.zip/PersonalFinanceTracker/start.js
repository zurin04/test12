// Simple start script for the personal finance tracker
const { spawn } = require('child_process');

// Start the server
const server = spawn('tsx', ['server/index.ts'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '3001' }
});

// Start the client
const client = spawn('vite', ['--port', '3000'], {
  stdio: 'inherit',
  cwd: 'client'
});

// Handle process termination
process.on('SIGINT', () => {
  server.kill('SIGINT');
  client.kill('SIGINT');
  process.exit(0);
});

console.log('Starting Personal Finance Tracker...');
console.log('Server running on port 3001');
console.log('Client running on port 3000');