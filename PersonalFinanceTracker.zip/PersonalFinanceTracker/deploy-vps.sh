#!/bin/bash

# Personal Finance Tracker - Production VPS Deployment
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "Personal Finance Tracker Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx python3 build-essential

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
APP_DIR="/var/www/finance-tracker"
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS finance_tracker_db;
DROP USER IF EXISTS finance_tracker_user;
CREATE USER finance_tracker_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE finance_tracker_db OWNER finance_tracker_user;
GRANT ALL PRIVILEGES ON DATABASE finance_tracker_db TO finance_tracker_user;
\q
EOF

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://finance_tracker_user:$DB_PASSWORD@localhost:5432/finance_tracker_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_tracker_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=finance_tracker_db
REPLIT_DOMAINS=localhost:5000
REPL_ID=production-vps
ISSUER_URL=https://replit.com/oidc
ENV

# Install dependencies 
print_status "Installing dependencies..."
npm install

# Setup database schema
print_status "Initializing database..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi
export DATABASE_URL="postgresql://finance_tracker_user:$DB_PASSWORD_ENCODED@localhost:5432/finance_tracker_db"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection first
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U finance_tracker_user -d finance_tracker_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

# Create drizzle configuration for production
print_status "Creating drizzle configuration..."
cat > drizzle.config.ts << 'DRIZZLE_CONFIG'
import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  dialect: 'postgresql',
  schema: './shared/schema.ts',
  out: './drizzle',
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
});
DRIZZLE_CONFIG

print_status "Pushing database schema..."
# Try with encoded URL first, then fallback to direct connection
if ! npx drizzle-kit push 2>&1; then
    print_warning "Schema push with encoded URL failed, trying direct connection..."
    # Try with raw password
    export DATABASE_URL="postgresql://finance_tracker_user:$DB_PASSWORD@localhost:5432/finance_tracker_db"
    if ! npx drizzle-kit push 2>&1; then
        print_error "Database schema push failed with both URL formats."
        exit 1
    fi
fi

# Update .env file with working DATABASE_URL
print_status "Updating environment configuration with working database URL..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_tracker_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=finance_tracker_db
REPLIT_DOMAINS=localhost:5000
REPL_ID=production-vps
ISSUER_URL=https://replit.com/oidc
ENV

# Build application with extended timeout and memory optimization
print_status "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"

# Build client
print_status "Building client..."
cd client
if timeout 600 npm run build 2>/dev/null || timeout 600 npx vite build; then
    print_status "Client built successfully"
else
    print_warning "Client build failed, trying fallback strategy..."
    export NODE_OPTIONS="--max-old-space-size=2048"
    if timeout 300 npx vite build; then
        print_status "Client built with fallback strategy"
    else
        print_error "Client build failed even with fallback strategy."
        exit 1
    fi
fi
cd ..

# Create PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.js << 'PM2_CONFIG'
module.exports = {
  apps: [{
    name: 'finance-tracker',
    script: './server/index.ts',
    interpreter: 'tsx',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/finance-tracker/error.log',
    out_file: '/var/log/finance-tracker/out.log',
    log_file: '/var/log/finance-tracker/combined.log',
    time: true
  }]
};
PM2_CONFIG

# Configure PM2 and services
print_status "Configuring services..."
sudo mkdir -p /var/log/finance-tracker
sudo chown $USER:$USER /var/log/finance-tracker

# Export environment variables for PM2
export DATABASE_URL
export SESSION_SECRET
export NODE_ENV=production
export PORT=5000
export PGHOST=localhost
export PGPORT=5432
export PGUSER=finance_tracker_user
export PGPASSWORD="$DB_PASSWORD"
export PGDATABASE=finance_tracker_db

# Configure Nginx for both server and client
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/finance-tracker > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    # Serve static files from client build
    root /var/www/finance-tracker/client/dist;
    index index.html;
    
    # Try to serve static files first, then fall back to proxy
    location / {
        try_files $uri $uri/ @proxy;
    }
    
    # Proxy API requests to backend
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Proxy auth requests to backend
    location /auth {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Fallback proxy for SPA routing
    location @proxy {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;
}
EOF

sudo ln -sf /etc/nginx/sites-available/finance-tracker /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "finance-tracker.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs finance-tracker"
    exit 1
fi

# Setup security and management
print_status "Finalizing setup..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Create management script
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/finance-tracker"
APP_DIR="/var/www/finance-tracker"

backup_database() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    echo "Creating database backup..."
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$PGPASSWORD" ]; then
        PGPASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U finance_tracker_user finance_tracker_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        # Keep only last 7 backups
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        echo "✓ Old backups cleaned up (keeping last 7)"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$2
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: $0 restore /path/to/backup.sql"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        echo "✗ Backup file not found: $backup_file"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    echo "Stopping application..."
    pm2 stop finance-tracker
    
    echo "Restoring database from: $backup_file"
    
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_tracker_user -d finance_tracker_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_tracker_user finance_tracker_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start finance-tracker
        echo "✓ Application restarted"
    else
        echo "✗ Restore failed!"
        pm2 start finance-tracker
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    # Create pre-update backup
    echo "Creating pre-update backup..."
    backup_database
    
    # Stop application
    echo "Stopping application..."
    pm2 stop finance-tracker
    
    # Update code
    echo "Pulling latest changes..."
    if git pull; then
        echo "✓ Code updated"
    else
        echo "✗ Git pull failed!"
        pm2 start finance-tracker
        exit 1
    fi
    
    # Install dependencies
    echo "Installing dependencies..."
    if npm install; then
        echo "✓ Dependencies updated"
    else
        echo "✗ npm install failed!"
        pm2 start finance-tracker
        exit 1
    fi
    
    # Update database schema
    echo "Updating database schema..."
    if npx drizzle-kit push; then
        echo "✓ Database schema updated"
    else
        echo "✗ Database migration failed!"
        echo "Restoring from backup..."
        # Find the most recent backup
        LATEST_BACKUP=$(ls -t $BACKUP_DIR/backup_*.sql | head -1)
        restore_database restore $LATEST_BACKUP
        exit 1
    fi
    
    # Build application
    echo "Building application..."
    cd client
    export NODE_OPTIONS="--max-old-space-size=4096"
    if timeout 600 npx vite build; then
        echo "✓ Client built"
        cd ..
    else
        echo "✗ Client build failed!"
        cd ..
        pm2 start finance-tracker
        exit 1
    fi
    
    # Start application
    echo "Starting application..."
    pm2 start finance-tracker
    
    # Verify application is running
    sleep 5
    if pm2 list | grep -q "finance-tracker.*online"; then
        echo "✓ Update completed successfully!"
    else
        echo "✗ Application failed to start after update!"
        echo "Check logs with: pm2 logs finance-tracker"
    fi
}

ssl_setup() {
    local domain=$2
    if [ -z "$domain" ]; then
        echo "Usage: $0 ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL certificate for $domain..."
    
    # Update nginx configuration with domain
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/finance-tracker
    sudo nginx -t && sudo systemctl reload nginx
    
    # Get SSL certificate
    if sudo certbot --nginx -d $domain --non-interactive --agree-tos --email admin@$domain; then
        echo "✓ SSL certificate installed successfully!"
        echo "✓ Your application is now available at: https://$domain"
    else
        echo "✗ SSL certificate installation failed!"
        exit 1
    fi
}

case "$1" in
    backup)
        backup_database
        ;;
    restore)
        restore_database "$@"
        ;;
    update)
        safe_update
        ;;
    ssl)
        ssl_setup "$@"
        ;;
    status)
        pm2 list
        echo ""
        echo "Application logs:"
        pm2 logs finance-tracker --lines 20
        ;;
    restart)
        pm2 restart finance-tracker
        ;;
    stop)
        pm2 stop finance-tracker
        ;;
    start)
        pm2 start finance-tracker
        ;;
    *)
        echo "Usage: $0 {backup|restore|update|ssl|status|restart|stop|start}"
        echo ""
        echo "Commands:"
        echo "  backup           - Create database backup"
        echo "  restore <file>   - Restore database from backup"
        echo "  update           - Safe update with backup"
        echo "  ssl <domain>     - Setup SSL certificate"
        echo "  status           - Show application status and logs"
        echo "  restart          - Restart application"
        echo "  stop             - Stop application"
        echo "  start            - Start application"
        exit 1
        ;;
esac
SCRIPT

chmod +x manage.sh

# Create verification script
cat > verify-deployment.sh << 'VERIFY_SCRIPT'
#!/bin/bash

echo "======================================"
echo "Personal Finance Tracker Verification"
echo "======================================"

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

check_service() {
    if systemctl is-active --quiet $1; then
        echo -e "${GREEN}✓${NC} $1 is running"
    else
        echo -e "${RED}✗${NC} $1 is not running"
        return 1
    fi
}

check_port() {
    if ss -tuln | grep -q ":$1 "; then
        echo -e "${GREEN}✓${NC} Port $1 is open"
    else
        echo -e "${RED}✗${NC} Port $1 is not open"
        return 1
    fi
}

check_url() {
    if curl -s -o /dev/null -w "%{http_code}" $1 | grep -q "200\|302"; then
        echo -e "${GREEN}✓${NC} $1 is accessible"
    else
        echo -e "${RED}✗${NC} $1 is not accessible"
        return 1
    fi
}

echo "Checking system services..."
check_service postgresql
check_service nginx

echo ""
echo "Checking ports..."
check_port 80
check_port 5432

echo ""
echo "Checking PM2 processes..."
if pm2 list | grep -q "finance-tracker.*online"; then
    echo -e "${GREEN}✓${NC} Finance Tracker application is running"
else
    echo -e "${RED}✗${NC} Finance Tracker application is not running"
fi

echo ""
echo "Checking application accessibility..."
check_url "http://localhost"

echo ""
echo "Database connection test..."
if [ -f .env ]; then
    source .env
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_tracker_user -d finance_tracker_db -c "SELECT 1;" >/dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} Database connection successful"
    else
        echo -e "${RED}✗${NC} Database connection failed"
    fi
else
    echo -e "${RED}✗${NC} Environment file not found"
fi

echo ""
echo "Deployment verification complete!"
echo "Application should be accessible at: http://$(curl -s ifconfig.me || echo 'your-server-ip')"
echo ""
echo "Management commands:"
echo "  ./manage.sh status    - Check application status"
echo "  ./manage.sh backup    - Create database backup"
echo "  ./manage.sh ssl <domain> - Setup SSL certificate"
VERIFY_SCRIPT

chmod +x verify-deployment.sh

print_status "Deployment completed successfully!"
print_status "Running verification..."
./verify-deployment.sh

echo ""
echo "======================================"
echo "DEPLOYMENT COMPLETE!"
echo "======================================"
echo ""
echo "🎉 Your Personal Finance Tracker is now running!"
echo ""
echo "📍 Access your application at: http://$(curl -s ifconfig.me || echo 'your-server-ip')"
echo ""
echo "🔧 Management commands:"
echo "   ./manage.sh status    - Check application status"
echo "   ./manage.sh backup    - Create database backup"
echo "   ./manage.sh update    - Safe update with backup"
echo "   ./manage.sh ssl <domain> - Setup SSL certificate"
echo ""
echo "📊 Monitor your application:"
echo "   pm2 logs finance-tracker  - View application logs"
echo "   pm2 monit                 - Real-time monitoring"
echo ""
echo "🔐 Database credentials saved in .env file"
echo "💾 Automatic backups available with ./manage.sh backup"
echo ""
echo "Next steps:"
echo "1. Point your domain to this server's IP"
echo "2. Run './manage.sh ssl yourdomain.com' to enable HTTPS"
echo "3. Configure authentication settings in the application"
echo ""
echo "======================================"