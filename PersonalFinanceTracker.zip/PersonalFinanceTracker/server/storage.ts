import {
  users,
  tasks,
  incomes,
  expenses,
  bills,
  goals,
  currencySettings,
  type User,
  type Task,
  type Income,
  type Expense,
  type Bill,
  type Goal,
  type CurrencySettings,
  type UpsertUser,
  type InsertTask,
  type InsertIncome,
  type InsertExpense,
  type InsertBill,
  type InsertGoal,
  type InsertCurrencySettings,
  type Currency,
  type PnLData
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Task operations
  getTasks(): Promise<Task[]>;
  getTaskById(id: string): Promise<Task | null>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<InsertTask>): Promise<Task>;
  deleteTask(id: string): Promise<void>;

  // Income operations
  getIncomes(): Promise<Income[]>;
  getIncomeById(id: string): Promise<Income | null>;
  createIncome(income: InsertIncome): Promise<Income>;
  updateIncome(id: string, updates: Partial<InsertIncome>): Promise<Income>;
  deleteIncome(id: string): Promise<void>;

  // Expense operations
  getExpenses(): Promise<Expense[]>;
  getExpenseById(id: string): Promise<Expense | null>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, updates: Partial<InsertExpense>): Promise<Expense>;
  deleteExpense(id: string): Promise<void>;

  // Bill operations
  getBills(): Promise<Bill[]>;
  getBillById(id: string): Promise<Bill | null>;
  createBill(bill: InsertBill): Promise<Bill>;
  updateBill(id: string, updates: Partial<InsertBill>): Promise<Bill>;
  deleteBill(id: string): Promise<void>;

  // Goal operations
  getGoals(): Promise<Goal[]>;
  getGoalById(id: string): Promise<Goal | null>;
  createGoal(goal: InsertGoal): Promise<Goal>;
  updateGoal(id: string, updates: Partial<InsertGoal>): Promise<Goal>;
  deleteGoal(id: string): Promise<void>;

  // Currency settings operations
  getCurrencySettings(userId: string): Promise<CurrencySettings | null>;
  createCurrencySettings(settings: InsertCurrencySettings): Promise<CurrencySettings>;
  updateCurrencySettings(userId: string, updates: Partial<InsertCurrencySettings>): Promise<CurrencySettings>;

  // PnL calculation
  getPnLForDate(date: string, currency: Currency): Promise<PnLData>;
  getPnLForDateRange(startDate: string, endDate: string, currency: Currency): Promise<PnLData[]>;
}

export class DatabaseStorage implements IStorage {
  private generateId(): string {
    return crypto.randomUUID();
  }

  private exchangeRates: { [key: string]: number } = { 'USD': 1, 'PHP': 56.5 };

  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Task operations
  async getTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  async getTaskById(id: string): Promise<Task | null> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || null;
  }

  async createTask(taskData: InsertTask): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values({
        id: this.generateId(),
        ...taskData,
      })
      .returning();
    return task;
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<Task> {
    const [task] = await db
      .update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    if (!task) throw new Error('Task not found');
    return task;
  }

  async deleteTask(id: string): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  // Income operations
  async getIncomes(): Promise<Income[]> {
    return await db.select().from(incomes);
  }

  async getIncomeById(id: string): Promise<Income | null> {
    const [income] = await db.select().from(incomes).where(eq(incomes.id, id));
    return income || null;
  }

  async createIncome(incomeData: InsertIncome): Promise<Income> {
    const [income] = await db
      .insert(incomes)
      .values({
        id: this.generateId(),
        ...incomeData,
      })
      .returning();
    return income;
  }

  async updateIncome(id: string, updates: Partial<InsertIncome>): Promise<Income> {
    const [income] = await db
      .update(incomes)
      .set(updates)
      .where(eq(incomes.id, id))
      .returning();
    if (!income) throw new Error('Income not found');
    return income;
  }

  async deleteIncome(id: string): Promise<void> {
    await db.delete(incomes).where(eq(incomes.id, id));
  }

  // Expense operations
  async getExpenses(): Promise<Expense[]> {
    return await db.select().from(expenses);
  }

  async getExpenseById(id: string): Promise<Expense | null> {
    const [expense] = await db.select().from(expenses).where(eq(expenses.id, id));
    return expense || null;
  }

  async createExpense(expenseData: InsertExpense): Promise<Expense> {
    const [expense] = await db
      .insert(expenses)
      .values({
        id: this.generateId(),
        ...expenseData,
      })
      .returning();
    return expense;
  }

  async updateExpense(id: string, updates: Partial<InsertExpense>): Promise<Expense> {
    const [expense] = await db
      .update(expenses)
      .set(updates)
      .where(eq(expenses.id, id))
      .returning();
    if (!expense) throw new Error('Expense not found');
    return expense;
  }

  async deleteExpense(id: string): Promise<void> {
    await db.delete(expenses).where(eq(expenses.id, id));
  }

  // Bill operations
  async getBills(): Promise<Bill[]> {
    return await db.select().from(bills);
  }

  async getBillById(id: string): Promise<Bill | null> {
    const [bill] = await db.select().from(bills).where(eq(bills.id, id));
    return bill || null;
  }

  async createBill(billData: InsertBill): Promise<Bill> {
    const [bill] = await db
      .insert(bills)
      .values({
        id: this.generateId(),
        ...billData,
      })
      .returning();
    return bill;
  }

  async updateBill(id: string, updates: Partial<InsertBill>): Promise<Bill> {
    const [bill] = await db
      .update(bills)
      .set(updates)
      .where(eq(bills.id, id))
      .returning();
    if (!bill) throw new Error('Bill not found');
    return bill;
  }

  async deleteBill(id: string): Promise<void> {
    await db.delete(bills).where(eq(bills.id, id));
  }

  // Goal operations
  async getGoals(): Promise<Goal[]> {
    return await db.select().from(goals);
  }

  async getGoalById(id: string): Promise<Goal | null> {
    const [goal] = await db.select().from(goals).where(eq(goals.id, id));
    return goal || null;
  }

  async createGoal(goalData: InsertGoal): Promise<Goal> {
    const [goal] = await db
      .insert(goals)
      .values({
        id: this.generateId(),
        ...goalData,
      })
      .returning();
    return goal;
  }

  async updateGoal(id: string, updates: Partial<InsertGoal>): Promise<Goal> {
    const [goal] = await db
      .update(goals)
      .set(updates)
      .where(eq(goals.id, id))
      .returning();
    if (!goal) throw new Error('Goal not found');
    return goal;
  }

  async deleteGoal(id: string): Promise<void> {
    await db.delete(goals).where(eq(goals.id, id));
  }

  // Currency settings operations
  async getCurrencySettings(userId: string): Promise<CurrencySettings | null> {
    const [settings] = await db
      .select()
      .from(currencySettings)
      .where(eq(currencySettings.userId, userId));
    return settings || null;
  }

  async createCurrencySettings(settingsData: InsertCurrencySettings): Promise<CurrencySettings> {
    const [settings] = await db
      .insert(currencySettings)
      .values({
        id: this.generateId(),
        ...settingsData,
      })
      .returning();
    return settings;
  }

  async updateCurrencySettings(userId: string, updates: Partial<InsertCurrencySettings>): Promise<CurrencySettings> {
    const [settings] = await db
      .update(currencySettings)
      .set(updates)
      .where(eq(currencySettings.userId, userId))
      .returning();
    if (!settings) throw new Error('Currency settings not found');
    return settings;
  }

  // PnL calculation
  async getPnLForDate(date: string, currency: Currency): Promise<PnLData> {
    const targetDate = new Date(date);
    const startOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate());
    const endOfDay = new Date(targetDate.getFullYear(), targetDate.getMonth(), targetDate.getDate() + 1);

    const [incomesData, expensesData] = await Promise.all([
      db.select().from(incomes).where(
        and(
          gte(incomes.date, startOfDay),
          lte(incomes.date, endOfDay)
        )
      ),
      db.select().from(expenses).where(
        and(
          gte(expenses.date, startOfDay),
          lte(expenses.date, endOfDay)
        )
      )
    ]);

    const totalIncome = incomesData.reduce((sum, income) => {
      const amount = parseFloat(income.amount);
      return sum + this.convertCurrency(amount, income.currency, currency);
    }, 0);

    const totalExpenses = expensesData.reduce((sum, expense) => {
      const amount = parseFloat(expense.amount);
      return sum + this.convertCurrency(amount, expense.currency, currency);
    }, 0);

    return {
      date,
      income: totalIncome,
      expenses: totalExpenses,
      pnl: totalIncome - totalExpenses,
      currency,
    };
  }

  async getPnLForDateRange(startDate: string, endDate: string, currency: Currency): Promise<PnLData[]> {
    const results: PnLData[] = [];
    const start = new Date(startDate);
    const end = new Date(endDate);

    for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
      const dateStr = date.toISOString().split('T')[0];
      const pnlData = await this.getPnLForDate(dateStr, currency);
      results.push(pnlData);
    }

    return results;
  }

  private convertCurrency(amount: number, fromCurrency: Currency, toCurrency: Currency): number {
    if (fromCurrency === toCurrency) return amount;
    
    const fromRate = this.exchangeRates[fromCurrency];
    const toRate = this.exchangeRates[toCurrency];
    
    return (amount / fromRate) * toRate;
  }

  setExchangeRate(currency: Currency, rate: number): void {
    this.exchangeRates[currency] = rate;
  }
}

export const storage = new DatabaseStorage();