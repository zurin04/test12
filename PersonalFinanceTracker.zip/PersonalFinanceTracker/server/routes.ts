import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app, storage);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post('/api/tasks', isAuthenticated, async (req, res) => {
    try {
      const task = await storage.createTask(req.body);
      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.put('/api/tasks/:id', isAuthenticated, async (req, res) => {
    try {
      const task = await storage.updateTask(req.params.id, req.body);
      res.json(task);
    } catch (error) {
      console.error("Error updating task:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete('/api/tasks/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteTask(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Income routes
  app.get('/api/incomes', isAuthenticated, async (req, res) => {
    try {
      const incomes = await storage.getIncomes();
      res.json(incomes);
    } catch (error) {
      console.error("Error fetching incomes:", error);
      res.status(500).json({ message: "Failed to fetch incomes" });
    }
  });

  app.post('/api/incomes', isAuthenticated, async (req, res) => {
    try {
      const income = await storage.createIncome(req.body);
      res.json(income);
    } catch (error) {
      console.error("Error creating income:", error);
      res.status(500).json({ message: "Failed to create income" });
    }
  });

  app.put('/api/incomes/:id', isAuthenticated, async (req, res) => {
    try {
      const income = await storage.updateIncome(req.params.id, req.body);
      res.json(income);
    } catch (error) {
      console.error("Error updating income:", error);
      res.status(500).json({ message: "Failed to update income" });
    }
  });

  app.delete('/api/incomes/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteIncome(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting income:", error);
      res.status(500).json({ message: "Failed to delete income" });
    }
  });

  // Expense routes
  app.get('/api/expenses', isAuthenticated, async (req, res) => {
    try {
      const expenses = await storage.getExpenses();
      res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  app.post('/api/expenses', isAuthenticated, async (req, res) => {
    try {
      const expense = await storage.createExpense(req.body);
      res.json(expense);
    } catch (error) {
      console.error("Error creating expense:", error);
      res.status(500).json({ message: "Failed to create expense" });
    }
  });

  app.put('/api/expenses/:id', isAuthenticated, async (req, res) => {
    try {
      const expense = await storage.updateExpense(req.params.id, req.body);
      res.json(expense);
    } catch (error) {
      console.error("Error updating expense:", error);
      res.status(500).json({ message: "Failed to update expense" });
    }
  });

  app.delete('/api/expenses/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteExpense(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting expense:", error);
      res.status(500).json({ message: "Failed to delete expense" });
    }
  });

  // Bill routes
  app.get('/api/bills', isAuthenticated, async (req, res) => {
    try {
      const bills = await storage.getBills();
      res.json(bills);
    } catch (error) {
      console.error("Error fetching bills:", error);
      res.status(500).json({ message: "Failed to fetch bills" });
    }
  });

  app.post('/api/bills', isAuthenticated, async (req, res) => {
    try {
      const bill = await storage.createBill(req.body);
      res.json(bill);
    } catch (error) {
      console.error("Error creating bill:", error);
      res.status(500).json({ message: "Failed to create bill" });
    }
  });

  app.put('/api/bills/:id', isAuthenticated, async (req, res) => {
    try {
      const bill = await storage.updateBill(req.params.id, req.body);
      res.json(bill);
    } catch (error) {
      console.error("Error updating bill:", error);
      res.status(500).json({ message: "Failed to update bill" });
    }
  });

  app.delete('/api/bills/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteBill(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting bill:", error);
      res.status(500).json({ message: "Failed to delete bill" });
    }
  });

  // Goal routes
  app.get('/api/goals', isAuthenticated, async (req, res) => {
    try {
      const goals = await storage.getGoals();
      res.json(goals);
    } catch (error) {
      console.error("Error fetching goals:", error);
      res.status(500).json({ message: "Failed to fetch goals" });
    }
  });

  app.post('/api/goals', isAuthenticated, async (req, res) => {
    try {
      const goal = await storage.createGoal(req.body);
      res.json(goal);
    } catch (error) {
      console.error("Error creating goal:", error);
      res.status(500).json({ message: "Failed to create goal" });
    }
  });

  app.put('/api/goals/:id', isAuthenticated, async (req, res) => {
    try {
      const goal = await storage.updateGoal(req.params.id, req.body);
      res.json(goal);
    } catch (error) {
      console.error("Error updating goal:", error);
      res.status(500).json({ message: "Failed to update goal" });
    }
  });

  app.delete('/api/goals/:id', isAuthenticated, async (req, res) => {
    try {
      await storage.deleteGoal(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting goal:", error);
      res.status(500).json({ message: "Failed to delete goal" });
    }
  });

  // Currency settings routes
  app.get('/api/currency-settings/:userId', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.getCurrencySettings(req.params.userId);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching currency settings:", error);
      res.status(500).json({ message: "Failed to fetch currency settings" });
    }
  });

  app.post('/api/currency-settings', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.createCurrencySettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error creating currency settings:", error);
      res.status(500).json({ message: "Failed to create currency settings" });
    }
  });

  app.put('/api/currency-settings/:userId', isAuthenticated, async (req, res) => {
    try {
      const settings = await storage.updateCurrencySettings(req.params.userId, req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating currency settings:", error);
      res.status(500).json({ message: "Failed to update currency settings" });
    }
  });

  // PnL routes
  app.get('/api/pnl/:date', isAuthenticated, async (req, res) => {
    try {
      const currency = req.query.currency as string || 'USD';
      const pnlData = await storage.getPnLForDate(req.params.date, currency as any);
      res.json(pnlData);
    } catch (error) {
      console.error("Error fetching PnL data:", error);
      res.status(500).json({ message: "Failed to fetch PnL data" });
    }
  });

  app.get('/api/pnl/:startDate/:endDate', isAuthenticated, async (req, res) => {
    try {
      const currency = req.query.currency as string || 'USD';
      const pnlData = await storage.getPnLForDateRange(
        req.params.startDate,
        req.params.endDate,
        currency as any
      );
      res.json(pnlData);
    } catch (error) {
      console.error("Error fetching PnL range data:", error);
      res.status(500).json({ message: "Failed to fetch PnL range data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}