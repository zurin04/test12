import express from 'express';
import cors from 'cors';
import { registerRoutes } from './routes';

async function startServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());

  // Routes with authentication
  const server = await registerRoutes(app);

  const PORT = process.env.PORT || 3000;

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });

  return { app, server };
}

startServer().catch(console.error);